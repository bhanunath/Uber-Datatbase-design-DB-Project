-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`vehicles`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`vehicles` (
  `vehicleID` INT NOT NULL,
  `vehicle_Model` VARCHAR(45) NOT NULL,
  `vehicle_InsuranceNo` VARCHAR(45) NOT NULL,
  `vehicle_RegisteredNumber` VARCHAR(45) NOT NULL,
  `vehicle_Company` VARCHAR(45) NOT NULL,
  `vehicle_InsuranceExpiry` DATE NOT NULL,
  `vehicle_LastChecked` DATE NOT NULL,
  PRIMARY KEY (`vehicleID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`drivers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`drivers` (
  `driverId` INT NOT NULL,
  `driver_FirstName` VARCHAR(45) NOT NULL,
  `driver_LastName` VARCHAR(45) NOT NULL,
  `driver_gender` VARCHAR(45) NOT NULL,
  `driver_phoneNumber` VARCHAR(45) NOT NULL,
  `driver_rating` INT NOT NULL,
  `vehicleID` INT NOT NULL,
  PRIMARY KEY (`driverId`),
  INDEX `fk_Driver_Vehicle1_idx` (`vehicleID` ASC) VISIBLE,
  CONSTRAINT `fk_Driver_Vehicle1`
    FOREIGN KEY (`vehicleID`)
    REFERENCES `mydb`.`vehicles` (`vehicleID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`customers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`customers` (
  `customerID` INT NOT NULL,
  `customer_FirstName` VARCHAR(45) NOT NULL,
  `customer_LastName` VARCHAR(45) NOT NULL,
  `customer_age` INT NOT NULL,
  `customer_gender` VARCHAR(45) NOT NULL,
  `customer_address` VARCHAR(45) NOT NULL,
  `customer_phoneNumber` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`customerID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`trips`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`trips` (
  `tripId` INT NOT NULL,
  `trip_date` DATE NOT NULL,
  `trip_time` TIME NOT NULL,
  `trip_charges` FLOAT NOT NULL,
  `trip_pickupLocation` VARCHAR(250) NOT NULL,
  `trip_dropLocation` VARCHAR(250) NOT NULL,
  `driverID` INT NOT NULL,
  `customerID` INT NOT NULL,
  `vehicleID` INT NOT NULL,
  PRIMARY KEY (`tripId`),
  INDEX `fk_Trip_Driver_idx` (`driverID` ASC) VISIBLE,
  INDEX `fk_Trip_Customer1_idx` (`customerID` ASC) VISIBLE,
  INDEX `fk_trips_vehicles1_idx` (`vehicleID` ASC) VISIBLE,
  CONSTRAINT `fk_Trip_Driver`
    FOREIGN KEY (`driverID`)
    REFERENCES `mydb`.`drivers` (`driverId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Trip_Customer1`
    FOREIGN KEY (`customerID`)
    REFERENCES `mydb`.`customers` (`customerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_trips_vehicles1`
    FOREIGN KEY (`vehicleID`)
    REFERENCES `mydb`.`vehicles` (`vehicleID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`customer_record`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`customer_record` (
  `recordID` INT NOT NULL,
  `tripStatus` VARCHAR(45) NOT NULL,
  `trip_count` INT NOT NULL,
  `customerID` INT NOT NULL,
  PRIMARY KEY (`recordID`),
  INDEX `fk_customer_record_Customer1_idx` (`customerID` ASC) VISIBLE,
  CONSTRAINT `fk_customer_record_Customer1`
    FOREIGN KEY (`customerID`)
    REFERENCES `mydb`.`customers` (`customerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`bill`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`bill` (
  `billID` INT NOT NULL,
  `billStatus` TINYINT NOT NULL,
  `tripID` INT NOT NULL,
  PRIMARY KEY (`billID`),
  INDEX `fk_bill_Trip1_idx` (`tripID` ASC) VISIBLE,
  CONSTRAINT `fk_bill_Trip1`
    FOREIGN KEY (`tripID`)
    REFERENCES `mydb`.`trips` (`tripId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`payments`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`payments` (
  `paymentID` INT NOT NULL,
  `paymentAmount` FLOAT NOT NULL,
  `paymentDate` DATE NOT NULL,
  `payment_Type` VARCHAR(45) NOT NULL,
  `billID` INT NOT NULL,
  PRIMARY KEY (`paymentID`),
  INDEX `fk_Payment_bill1_idx` (`billID` ASC) VISIBLE,
  CONSTRAINT `fk_Payment_bill1`
    FOREIGN KEY (`billID`)
    REFERENCES `mydb`.`bill` (`billID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
