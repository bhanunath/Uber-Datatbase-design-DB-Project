USE `mydb`;
DROP procedure IF EXISTS `InsertNewVehicle`;

USE `mydb`;
DROP procedure IF EXISTS `mydb`.`InsertNewVehicle`;
;

DELIMITER $$
USE `mydb`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertNewVehicle`(
	vehicleID INT ,
	vehicle_Model VARCHAR(45),
    vehicle_InsuranceNo VARCHAR(45),
    vehicle_RegisteredNumber VARCHAR(45),
    vehicle_Company VARCHAR(45),
    vehicle_InsuranceExpiry DATE,
    vehicle_LastChecked DATE
    
)
BEGIN
 INSERT INTO vehicles
 VALUES (vehicleID ,
	vehicle_Model ,
    vehicle_InsuranceNo ,
    vehicle_RegisteredNumber,
    vehicle_Company ,
    vehicle_InsuranceExpiry,
    vehicle_LastChecked);
END$$

DELIMITER ;
;