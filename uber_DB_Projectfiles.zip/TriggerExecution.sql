

INSERT INTO customers VALUES ('112', 'Koushik', 'Kumar', '81', 'Male', '895 main street', '986325471');


