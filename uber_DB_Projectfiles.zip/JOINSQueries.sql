use `mydb`;

-- customers who have pending bill --
select c.customerID,c.customer_FirstName,t.tripID,b.billID from customers c INNER JOIN trips t ON c.customerID = t.customerID 
INNER JOIN bill b on t.tripID = b.tripID where b.billStatus='0';

-- customers whose tripStatus is Finished  --
SELECT c.customerID,c.customer_FirstName ,c.customer_LastName,cr.tripStatus
FROM customers c
INNER JOIN customer_record cr ON c.customerId = cr.customerId
WHERE cr.tripStatus = 'Finished';


select * from bill ;
select * from trips ;
select * from customers ;

select * from customer_record ;


