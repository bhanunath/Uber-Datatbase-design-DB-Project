use `mydb`;

INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
VALUES ('100', 'Jon', 'Doe', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('101', 'Johny', 'Salvatore', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('102', 'Sidd', 'Salvatore', '16', 'Male', '123 ,plays garden', '489788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('103', 'Johny', 'rakesh', '20', 'Female', 'graphic era', '696788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('104', 'subha', 'Salvatore', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('105', 'suja', 'Salvatore', '19', 'Female', '123 street', '456778876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('106', 'Johny', 'Salvatore', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('107', 'manav', 'Salvatore', '41', 'Male', '123 street', '676788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('108', 'doe', 'Coven', '19', 'Male', '1234 streets', '456756876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('109', 'Joy', 'Tribbiani', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('110', 'Jsed', 'Coven', '19', 'Male', '123 street', '453488876');

select * from customers ;


INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('1234', 'AUDI', '123445', 'KK', 'Audi', '2003-11-11', '2003-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('12456734', 'MG', '123423445', 'KK', 'Audi', '2003-11-11', '2003-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('1254734', 'Maruti', '123345445', 'KK', 'Audi', '2003-11-11', '2003-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('1245734', 'Suzuki', '123453445', 'KK', 'Audi', '2003-11-11', '2003-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('1225334', 'Tata', '12346845', 'KK', 'Audi', '2001-11-11', '2008-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('123674', 'AUDI', '12345683445', 'KK', 'Audi', '2001-11-11', '2007-11-11');


select * from vehicles ;

INSERT INTO drivers(driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('200', 'Jone', 'Rock', 'Male', '9685743210', '3', '123674');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('201','John', 'Doe', 'Male', '4567888762', '3', '1254734');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('202','Sidd', 'Sriram', 'Male', '4897888762','5', '1254734');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('203','Elena', 'Gilbert', 'Female', '6967288876', '2', '123674');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('204', 'Joey', 'Tribbiani','Male', '4567882876', '1', '1254734');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('205','Phoebe', 'Buffay', 'Female', '4562778876','2', '123674');


select * from drivers ;


INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('300', '2002-11-11', '15:50:00', '700', 'NewBedford', 'FallRiver','201','102','1234');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('301', '2003-09-11', '16:50:00', '500', 'FallRiver', 'NewBedford','202','103','1234');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('302', '2005-10-11', '17:50:00', '550', 'NewBedford', 'UMass','205','105','123674');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('303', '2006-01-11', '18:50:00', '600', 'UMass', 'FallRiver','203','110','1234');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('304', '2008-07-10', '19:26:00', '650', 'UMass', 'NewBedford','200','108','1254734');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('305', '2009-11-11', '20:32:00', '250', 'FallRiver', 'UMass','202','106','123674');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('306', '2010-11-11', '22:52:00', '350', 'NewBedford', 'FallRiver','205','106','1234');

select * from trips ;



INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('400', 'Ongoing' , '20','105');
INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('401', 'Finished' , '25','102');
INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('402', 'Not Started' , '45','110');
INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('403', 'Finished' , '15','109');
INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('404', 'Finished' , '18','101');

select * from customer_record ;

INSERT INTO bill(billID, billStatus, tripID) VALUES ('500', '1', '302');
INSERT INTO bill(billID, billStatus, tripID) VALUES ('501', '0', '305');
INSERT INTO bill(billID, billStatus, tripID) VALUES ('502', '1', '301');
INSERT INTO bill(billID, billStatus, tripID) VALUES ('503', '1', '304');
INSERT INTO bill(billID, billStatus, tripID) VALUES ('504', '0', '306');

select * from bill;


INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('600', '4373.96', '2007-10-11', 'Card','502');
INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('601', '7324.69', '2008-10-11', 'Cash','504');
INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('602', '8754.83', '2009-10-11', 'Cash','500');
INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('603', '9732.39', '2010-10-11', 'Card','501');
INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('604', '6234.58', '2011-10-11', 'Card','503');



select * from customers ;
select * from vehicles ;
select * from drivers ;
select * from trips ;
select * from customer_record ;
select * from bill ;
select * from payments ;

Delete from vehicles;




