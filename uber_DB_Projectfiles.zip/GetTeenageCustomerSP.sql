USE `mydb`;
DROP procedure IF EXISTS `GetTeenageCustomers`;

USE `mydb`;
DROP procedure IF EXISTS `mydb`.`GetTeenageCustomers`;
;

DELIMITER $$
USE `mydb`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetTeenageCustomers`()
BEGIN
	Select customer_FirstName,customer_age from customers where customer_age < 20 ;
    

END$$

DELIMITER ;
;

