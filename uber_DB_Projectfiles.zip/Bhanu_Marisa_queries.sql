-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`vehicles`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`vehicles` (
  `vehicleID` INT NOT NULL,
  `vehicle_Model` VARCHAR(45) NOT NULL,
  `vehicle_InsuranceNo` VARCHAR(45) NOT NULL,
  `vehicle_RegisteredNumber` VARCHAR(45) NOT NULL,
  `vehicle_Company` VARCHAR(45) NOT NULL,
  `vehicle_InsuranceExpiry` DATE NOT NULL,
  `vehicle_LastChecked` DATE NOT NULL,
  PRIMARY KEY (`vehicleID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`drivers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`drivers` (
  `driverId` INT NOT NULL,
  `driver_FirstName` VARCHAR(45) NOT NULL,
  `driver_LastName` VARCHAR(45) NOT NULL,
  `driver_gender` VARCHAR(45) NOT NULL,
  `driver_phoneNumber` VARCHAR(45) NOT NULL,
  `driver_rating` INT NOT NULL,
  `vehicleID` INT NOT NULL,
  PRIMARY KEY (`driverId`),
  INDEX `fk_Driver_Vehicle1_idx` (`vehicleID` ASC) VISIBLE,
  CONSTRAINT `fk_Driver_Vehicle1`
    FOREIGN KEY (`vehicleID`)
    REFERENCES `mydb`.`vehicles` (`vehicleID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`customers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`customers` (
  `customerID` INT NOT NULL,
  `customer_FirstName` VARCHAR(45) NOT NULL,
  `customer_LastName` VARCHAR(45) NOT NULL,
  `customer_age` INT NOT NULL,
  `customer_gender` VARCHAR(45) NOT NULL,
  `customer_address` VARCHAR(45) NOT NULL,
  `customer_phoneNumber` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`customerID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`trips`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`trips` (
  `tripId` INT NOT NULL,
  `trip_date` DATE NOT NULL,
  `trip_time` TIME NOT NULL,
  `trip_charges` FLOAT NOT NULL,
  `trip_pickupLocation` VARCHAR(250) NOT NULL,
  `trip_dropLocation` VARCHAR(250) NOT NULL,
  `driverID` INT NOT NULL,
  `customerID` INT NOT NULL,
  `vehicleID` INT NOT NULL,
  PRIMARY KEY (`tripId`),
  INDEX `fk_Trip_Driver_idx` (`driverID` ASC) VISIBLE,
  INDEX `fk_Trip_Customer1_idx` (`customerID` ASC) VISIBLE,
  INDEX `fk_trips_vehicles1_idx` (`vehicleID` ASC) VISIBLE,
  CONSTRAINT `fk_Trip_Driver`
    FOREIGN KEY (`driverID`)
    REFERENCES `mydb`.`drivers` (`driverId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Trip_Customer1`
    FOREIGN KEY (`customerID`)
    REFERENCES `mydb`.`customers` (`customerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_trips_vehicles1`
    FOREIGN KEY (`vehicleID`)
    REFERENCES `mydb`.`vehicles` (`vehicleID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`customer_record`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`customer_record` (
  `recordID` INT NOT NULL,
  `tripStatus` VARCHAR(45) NOT NULL,
  `trip_count` INT NOT NULL,
  `customerID` INT NOT NULL,
  PRIMARY KEY (`recordID`),
  INDEX `fk_customer_record_Customer1_idx` (`customerID` ASC) VISIBLE,
  CONSTRAINT `fk_customer_record_Customer1`
    FOREIGN KEY (`customerID`)
    REFERENCES `mydb`.`customers` (`customerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`bill`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`bill` (
  `billID` INT NOT NULL,
  `billStatus` TINYINT NOT NULL,
  `tripID` INT NOT NULL,
  PRIMARY KEY (`billID`),
  INDEX `fk_bill_Trip1_idx` (`tripID` ASC) VISIBLE,
  CONSTRAINT `fk_bill_Trip1`
    FOREIGN KEY (`tripID`)
    REFERENCES `mydb`.`trips` (`tripId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`payments`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`payments` (
  `paymentID` INT NOT NULL,
  `paymentAmount` FLOAT NOT NULL,
  `paymentDate` DATE NOT NULL,
  `payment_Type` VARCHAR(45) NOT NULL,
  `billID` INT NOT NULL,
  PRIMARY KEY (`paymentID`),
  INDEX `fk_Payment_bill1_idx` (`billID` ASC) VISIBLE,
  CONSTRAINT `fk_Payment_bill1`
    FOREIGN KEY (`billID`)
    REFERENCES `mydb`.`bill` (`billID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

==========================================================================================================================================

-- INSERTING DATA INTO TABLES --
------------------


INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
VALUES ('100', 'Jon', 'Doe', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('101', 'Johny', 'Salvatore', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('102', 'Sidd', 'Salvatore', '16', 'Male', '123 ,plays garden', '489788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('103', 'Johny', 'rakesh', '20', 'Female', 'graphic era', '696788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('104', 'subha', 'Salvatore', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('105', 'suja', 'Salvatore', '19', 'Female', '123 street', '456778876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('106', 'Johny', 'Salvatore', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('107', 'manav', 'Salvatore', '41', 'Male', '123 street', '676788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('108', 'doe', 'Coven', '19', 'Male', '1234 streets', '456756876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('109', 'Joy', 'Tribbiani', '19', 'Male', '123 street', '456788876');
INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
 VALUES ('110', 'Jsed', 'Coven', '19', 'Male', '123 street', '453488876');
-------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('1234', 'AUDI', '123445', 'KK', 'Audi', '2003-11-11', '2003-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('12456734', 'MG', '123423445', 'KK', 'Audi', '2003-11-11', '2003-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('1254734', 'Maruti', '123345445', 'KK', 'Audi', '2003-11-11', '2003-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('1245734', 'Suzuki', '123453445', 'KK', 'Audi', '2003-11-11', '2003-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('1225334', 'Tata', '12346845', 'KK', 'Audi', '2001-11-11', '2008-11-11');
INSERT INTO vehicles (vehicleID, vehicle_Model, vehicle_InsuranceNo, vehicle_RegisteredNumber, vehicle_Company, vehicle_InsuranceExpiry, vehicle_LastChecked)
 VALUES ('123674', 'AUDI', '12345683445', 'KK', 'Audi', '2001-11-11', '2007-11-11');

-------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO drivers(driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('200', 'Jone', 'Rock', 'Male', '9685743210', '3', '123674');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('201','John', 'Doe', 'Male', '4567888762', '3', '1254734');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('202','Sidd', 'Sriram', 'Male', '4897888762','5', '1254734');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('203','Elena', 'Gilbert', 'Female', '6967288876', '2', '123674');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('204', 'Joey', 'Tribbiani','Male', '4567882876', '1', '1254734');
INSERT INTO drivers (driverID, driver_FirstName, driver_LastName, driver_gender, driver_phoneNumber, driver_rating, vehicleID)
 VALUES ('205','Phoebe', 'Buffay', 'Female', '4562778876','2', '123674');

-------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('300', '2002-11-11', '15:50:00', '700', 'NewBedford', 'FallRiver','201','102','1234');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('301', '2003-09-11', '16:50:00', '500', 'FallRiver', 'NewBedford','202','103','1234');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('302', '2005-10-11', '17:50:00', '550', 'NewBedford', 'UMass','205','105','123674');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('303', '2006-01-11', '18:50:00', '600', 'UMass', 'FallRiver','203','110','1234');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('304', '2008-07-10', '19:26:00', '650', 'UMass', 'NewBedford','200','108','1254734');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('305', '2009-11-11', '20:32:00', '250', 'FallRiver', 'UMass','202','106','123674');
INSERT INTO trips(tripID,trip_date, trip_time, trip_charges, trip_pickupLocation, trip_dropLocation,driverID,customerID,vehicleID) 
VALUES ('306', '2010-11-11', '22:52:00', '350', 'NewBedford', 'FallRiver','205','106','1234');


-------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('400', 'Ongoing' , '20','105');
INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('401', 'Finished' , '25','102');
INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('402', 'Not Started' , '45','110');
INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('403', 'Finished' , '15','109');
INSERT INTO customer_record(recordID, tripStatus, trip_count, customerID) VALUES ('404', 'Finished' , '18','101');

-------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO bill(billID, billStatus, tripID) VALUES ('500', '1', '302');
INSERT INTO bill(billID, billStatus, tripID) VALUES ('501', '0', '305');
INSERT INTO bill(billID, billStatus, tripID) VALUES ('502', '1', '301');
INSERT INTO bill(billID, billStatus, tripID) VALUES ('503', '1', '304');
INSERT INTO bill(billID, billStatus, tripID) VALUES ('504', '0', '306');

-------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('600', '4373.96', '2007-10-11', 'Card','502');
INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('601', '7324.69', '2008-10-11', 'Cash','504');
INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('602', '8754.83', '2009-10-11', 'Cash','500');
INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('603', '9732.39', '2010-10-11', 'Card','501');
INSERT INTO payments (paymentID, paymentAmount, paymentDate, payment_Type, billID) 
VALUES ('604', '6234.58', '2011-10-11', 'Card','503');
-------------------------------------------------------------------------------------------------------------------------------------------------------


select * from customers ;
select * from vehicles ;
select * from drivers ;
select * from trips ;
select * from customer_record ;
select * from bill ;
select * from payments ;

-- JOIN QUERIES--

-- customers who have pending bill --
select c.customerID,c.customer_FirstName,t.tripID,b.billID from customers c INNER JOIN trips t ON c.customerID = t.customerID 
INNER JOIN bill b on t.tripID = b.tripID where b.billStatus='0';

-- customers whose tripStatus is Finished  --
SELECT c.customerID,c.customer_FirstName ,c.customer_LastName,cr.tripStatus
FROM customers c
INNER JOIN customer_record cr ON c.customerId = cr.customerId
WHERE cr.tripStatus = 'Finished';







