CALL GetTeenageCustomers();



CALL InsertNewVehicle('12990', 'Benz', '987569', 'GG', 'Mrcedes', '2015-09-10', '2019-08-27');




---------------------------
select * from vehicles ;


