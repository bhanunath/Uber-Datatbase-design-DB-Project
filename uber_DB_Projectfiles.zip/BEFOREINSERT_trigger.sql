select * from customers;

INSERT INTO customers (customerID, customer_FirstName, customer_LastName, customer_age, customer_gender, customer_address, customer_phoneNumber)
VALUES ('111', 'Virat', 'Kohli', '33', 'Male', '859 new street', NULL);
