-- BEFORE INSERT TRIGGER--

CREATE DEFINER=`root`@`localhost` TRIGGER `customers_BEFORE_INSERT` BEFORE INSERT ON `customers` FOR EACH ROW BEGIN
IF NEW.customer_age > 80 THEN 
SIGNAL SQLSTATE '50001' SET MESSAGE_TEXT = 'Person must be younger than 80';
END IF;
END

-- Trigger Execution Query--
INSERT INTO customers VALUES ('112', 'Koushik', 'Kumar', '81', 'Male', '895 main street', '986325471');






-- Stored procedures--

-- get teenage customers stored procedure--
USE `mydb`;
DROP procedure IF EXISTS `GetTeenageCustomers`;

USE `mydb`;
DROP procedure IF EXISTS `mydb`.`GetTeenageCustomers`;
;

DELIMITER $$
USE `mydb`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetTeenageCustomers`()
BEGIN
	Select customer_FirstName,customer_age from customers where customer_age < 20 ;
    

END$$

DELIMITER ;
;

-- getteenage customer execution query--
CALL GetTeenageCustomers();



-- insert new vehicle data stored procedure--

USE `mydb`;
DROP procedure IF EXISTS `InsertNewVehicle`;

USE `mydb`;
DROP procedure IF EXISTS `mydb`.`InsertNewVehicle`;
;

DELIMITER $$
USE `mydb`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertNewVehicle`(
	vehicleID INT ,
	vehicle_Model VARCHAR(45),
    vehicle_InsuranceNo VARCHAR(45),
    vehicle_RegisteredNumber VARCHAR(45),
    vehicle_Company VARCHAR(45),
    vehicle_InsuranceExpiry DATE,
    vehicle_LastChecked DATE
    
)
BEGIN
 INSERT INTO vehicles
 VALUES (vehicleID ,
	vehicle_Model ,
    vehicle_InsuranceNo ,
    vehicle_RegisteredNumber,
    vehicle_Company ,
    vehicle_InsuranceExpiry,
    vehicle_LastChecked);
END$$

DELIMITER ;
;


-- insert new vehicle data query--
CALL InsertNewVehicle('12990', 'Benz', '987569', 'GG', 'Mrcedes', '2015-09-10', '2019-08-27');




















